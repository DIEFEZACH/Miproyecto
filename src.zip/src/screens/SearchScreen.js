import React from "react";

import {View, Text, StyleSheet} from 'react-native'

export default function SearchScreen(){
    return(
        <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>
            <Text>Search Screen</Text>
        </View>
    )
}