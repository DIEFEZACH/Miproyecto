import React from "react";

import {View, Text, StyleSheet} from 'react-native'

export default function RestaurantsMapScreen(){
    return(
        <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>
            <Text>Restaurant Map Screen</Text>
        </View>
    )
}